---
title: 'Seeing'
---

H. says, “In psychology, pareidolia are images of clouds in the sky to which the human mind ascribes meaning. It’s a precursor to hallucination. But you would know, wouldn’t you?”
