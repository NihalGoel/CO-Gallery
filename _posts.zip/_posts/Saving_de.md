---
title: 'Speichern'
---
Jeff Bezos sagt, speichern sei günstiger als löschen. Ich finde die Quelle dieser Aussage nicht. Nach allem, was ich über die Logik von wirtschaftlichem Wachstum, den Umgang von Cloudanbietern mit Nutzerdaten und schließlich meinen Umgang mit dem eigenen Archiv weiß, habe ich keinen Zweifel daran, dass es stimmt.

* [Über diesen Text](About%20This%20Text_de)

* [Löschen](Saving_de)
