---
title: 'Trust'
---

“Clouds of smoke rose from the roof of the embassy. The American side confirmed that they were destroying ‘sensitive documents’ that they did not want handed over to the Taliban.” -!25!-
## <sub class="subscript">**25**</sub> [Majid Sattar, “Black Hawks im Pendelverkehr,” _Frankfurter Allgemeine Zeitung_, August 15, 2021,](https://www.faz.net/-gq5-aesmp) (accessed on September 8, 2021). Translated here by Sylee Gore.
**“In Afghanistan**, the radical Islamist Taliban also seems to have seized US military equipment used for biometric identification, along with the data it contains. . . . It’s possible that the Taliban may need additional tools to access the data. . . . However, Pakistani intelligence could be of use.” -!26!-
## <sub class="subscript">**26**</sub> [Martin Holland, “Afghanistan: Taliban erbeuten Biometrie-Geräte und -Datenbanken,” _heise.de_, August 18, 2021,retrieved from <u>[here</u>](https://www.heise.de/-6168158) (accessed on September 8, 2021). Translated here by Sylee Gore.


