---
title: 'Money'
---
“In 2020, Google Cloud lost $5.6
billion on its $13 billion revenue. . . . **Nice**
**going**, Google. Keep converting your money
into the cloud. Through combustion.” -!20!-
## <sub class="subscript">**20**</sub> [“Wed Feb 3 2021,” _Fefes Blog_, February 3, 2021, retrieved from <u>[here</u>](https://blog.fefe.de/?ts=9ee433ae) (accessed on September 8, 2021). Translated here by Sylee Gore.

* [The Cloud](Clouds_en)

* [Fire](Fire_en)

