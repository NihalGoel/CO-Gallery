---
title: 'Rechnen'
---

“Man fragte, ob sich das Universum womöglich vollständig durch Informationen beschreiben ließe. Gelänge das, könnte ein Computerprogramm prinzipiell die Wirklichkeit berechnen. In diesem Zusammenhang wurde der Begriff der ›digitalen Physik‹ geprägt und mit der These versinnbildlicht, dass das Universum eine digitale Rechenmaschine sei. Anhänger dieser theoretischen Perspektive fahndeten allerdings nicht nach Beweisen für eine simulierte Wirklichkeit. Vielmehr ging es ihnen um die fundamentale Struktur des Universums. Sind dessen kleinste Bausteine einzelne Informationseinheiten? Bislang gibt es dafür keine überzeugenden Belege. Wenn dem aber so wäre, dann könnte die Welt eine computergenerierte sein.” -!23!-

## <sub class="subscript">**23**</sub> Janosch Deeg, “Leben wir in einer Computersimulation?,” [_Frankfurter Allgemeine Zeitung_, August 13, 2021](https://www.faz.net/-ijr-aemc2)
