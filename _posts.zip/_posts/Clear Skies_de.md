---
title: 'Bombenwetter'
---

»Schon die erste Bombe hätte Nagasaki treffen können. Die Sichtverhältnisse dort waren exzellent, das Primärziel Hiroshima dagegen und die Stadt Kokura, dritter möglicher Zielort, blieben unter Wolken verborgen. Doch plötzlich riss der Himmel über Hiroshima auf, der Zielanflug der ›Enola Gay‹ begann. Nur eine kurze Frist wurde Nagasaki durch den meteorologischen Zufall geschenkt, dann fiel auch dort die Bombe, heute vor 60 Jahren.« -!5!-
## <sub class="subscript">**5**</sub> [Andreas Conrad: „Der Angriffs-Befehl kam aus Babelsberg“, in: _Der Tagesspiege_ l, 9. August 2005, hier zit <u>nach</u>](https://www.tagesspiegel.de/berlin/der-angriffs-befehl-kam-aus-babelsberg/631760.html) Zugriff 15. Juni 2021

* [Wetter](Weather_de)

* [Krieg](War_de)




