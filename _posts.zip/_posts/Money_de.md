---
title: 'Geld'
---
»Google Cloud hat 2020 bei 13 Milliarden Dollar Umsatz 5,6 Milliarden Verlust gemacht. [...] Ja toll, Google, dann wandelt mal euer Geld weiter in Wolken um. Per Verbrennung.« -!13!-
## <sub class="subscript">**13**</sub> [Fefes Blog, 3. Februar 2021, zit. <u>nach</u>](https://blog.fefe.de/?ts=9ee433ae)

* [Cloud](Clouds_de)

* [Feuer](Fire_de)
