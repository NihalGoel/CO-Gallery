---
title: 'Clouds'
---

“Orpheus stood and played and sang before this entrance, shrouded in the dark cloud of grief.” 
"**Zeus claimed** the heavens and the earth for himself, establishing his throne on Mount Olympus. The mountain is usually covered in clouds.” **“They promise** that he will be able to understand the language of the animals, to lie on the clouds. But this does not lure him out.” -!8!-
## <sub class="subscript">**8**</sub> Michael Köhlmeier, _Sagen des klassischen Altertums_ (Munich: Piper, 1996), 17, 77, 20 (accessed on September 8, 2021). Translated here by Sylee Gore.

* [Beginnings](Beginnings_en)

* [Clouds, Gray](Clozuds,%20Gray_en)

