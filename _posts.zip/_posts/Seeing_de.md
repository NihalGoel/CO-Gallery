---
title: 'Sehen'
---

H. sagt: »Pareidolien sind in der Psychologie die Wolkenbilder am Himmel, denen der menschliche Geist einen Sinn zuweist. Es sind somit Vorstufen der Halluzination. Das weißt du eh, oder?«

* [Fotografie](Photography_de)

* [Krieg](War_de)

* [Über diesen Text](About%20This%20Text_de)
