---
title: 'Weather'
---

It’s been raining for over twenty- four hours. We’re now essentially inside a cloud. The sky is blue and cloudless. Even on my short walk from the hotel to my makeshift workspace, the air still feels fresh. **After some** time has passed, individual clouds have begun reappearing in the sky, temporarily covering the sun. **The sky** is a flat gray. It starts raining again. **The rain** falls heavily and steadily. **The sky** grows lighter. The rain subsides. **Today the** cloud is as large as the castle on the mountain. It’s lighter on top than it is on the bottom. The sun fails to break through the clouds. **It becomes** much grayer again and starts raining. **It’s raining**. The gray sky is shot through with bright streaks. I still can’t believe how huge the clouds look in comparison to the castle. Of course, I know that the castle is six hundred meters away. And I also know that it’s all an optical illusion. But I’m amazed, nonetheless.
