---
title: 'Light'
---

I’m seventeen years old and I’ve been part of M.’s photography circle for a year now. I’m standing with him on the steps of the Schauspielhaus in Berlin. He is taking photos for a band of musicians, and I’m assisting him. The weather keeps changing. Every so often, the sun is temporarily obscured by a cloud. M. points out that this influences the lighting and the exposure time.

* [Photography](Photography_en)
