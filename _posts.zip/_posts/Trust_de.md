---
title: 'Vertrauen'
---

»Vom Dach der Botschaft stiegen Rauchwolken auf. Von amerikanischer Seite wurde bestätigt, dass man dabei sei, ›sensible Dokumente‹, die man nicht den Taliban überlassen wolle, zu vernichten.« -!24!-
## <sub class="subscript">**24**</sub> [Majid Sattar: _Black Hawks im Pendelverkehr_, in: _Frankfurter Allgemeine Zeitung_, 15. August 2021, hier zit. <u>nach</u>](https://www.faz.net/-gq5-aesmp).
**»In Afghanistan** haben die radikal-islamistischen Taliban offenbar auch Gerätschaften des US-Militärs zur biometrischen Personenidentifizierung erbeutet –inklusive der enthaltenen Daten. [...] Es sei möglich, dass die Taliban weitere Werkzeuge benötigen, um an die Daten zu gelangen [...]. Dabei könnte aber der pakistanische Geheimdienst helfen.« -!25!-
## <sub class="subscript">**25**</sub> [Martin Holland: _Afghanistan: Taliban erbeuten Biometrie-Geräte und –Datenbanken_, in: _heise.de_, 18. August 2021, zit. <u>nach</u>](https://www.heise.de/-6168158)
