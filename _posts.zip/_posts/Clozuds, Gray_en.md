---
title: 'Clouds, Gray'
---

“Wrapped in clouds, as in a mantle, / Now the great gods sleep together / And I hear them, bravely snoring. / And we’re having awful weather. **It grows** wilder; winds are howling / And the masts are bent like willows. / Who can curb the lordly tempest, / Put a bridle on the billows! **I can’t** stop it, let it come then; / Storms and terrors without number. I will wrap my mantle round me, / And, like any god, I’ll slumber.” -!9!-

## <sub class="subscript">**9**</sub> Heinrich Heine, “Eingehüllt in graue Wolken,” in _Poems of Heinrich Heine_, trans. Louis Untermeyer (New York: Harcourt, Brace, 1916), 151.
