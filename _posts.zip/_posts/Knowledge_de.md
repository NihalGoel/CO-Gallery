---
title: 'Wissen'
---

**Philo and Gunge:** Na, Du stehst im Angesicht der allwissenden Müllhalde, ja. Die Müllhalde weiß alles, die Müllhalde sagt alles. **Marjory**: Jawohl, so ist es. Das kommt daher, weil in mir so viel drin ist. Ich bin voller Orangenschalen und Kaffeesatz. Ich bin voller Weisheit. **Gobo**: Meine Verehrung Madamme. **Marjory**: Und ich weiß, was diesem Fraggle wie ein Stein auf dem Herzen liegt. **Philo and Gunge**: Natürlich weißt Du das. Du bist ja schließlich allwissend. **Marjory**: Auch das weiß ich. Unser junger Freund, der dort steht, hat Probleme. **Philo and Gunge**: Probleme? Gobo: Ja. Ich komme mit Problemen.Es tut mir leid. Ehrlich. **Marjory**: Wieso, was muss dir daran leidtun. Ich verschlinge Probleme mit Vergnügen. -!26!-
## <sub class="subscript">**26**</sub> _Die Fraggles_, Staffel 1, Episode 1, Der Anfang, Kanada / Großbritannien 1983.

* [Wolke](Clouds_de)

* [Dreck](Dirt_de)

* [Speichern](Saving_de)
