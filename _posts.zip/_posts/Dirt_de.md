---
title: 'Dreck'
---

»Die Anzahl und Größe der Eiskristalle zum Zeitpunkt der KondensstreifenBildung hängt von den Rußpartikelemissionen der Flugzeugtriebwerke ab.«-!7!-
## <sub class="subscript">**7**</sub> [_Klimaauswirkungen von Wolken aus Flugzeugkondensstreifen können sich bis 2050 verdreifachen_, Deutsches Zentrum für Luft- und Raumfahrt, Institut für Physik der Atmosphäre, 15. Juli 2019, hier zit. <u>nach</u>](https://www.dlr.de/content/de/artikel/news/2019/02/20190627_klimaauswirkung-von-wolken-aus-flugzeugkondensstreifen.html).
**»Während diese** in tieferen Atmosphärenschichten durch Regen ausgewaschen werden, verbleiben sie in den obersten Schichten drei bis zehn Jahre lang. Über die Jahre könnten dort einige Tausend Tonnen Ruß angesammelt werden. Die Teilchen ändern die Wechselwirkung zwischen Sonneneinstrahlung und Atmosphäre: Ruß absorbiert Sonnenlicht, während Aluminium es zurückwirft, beide Partikelarten absorbieren aber auch die langwellige Wärmestrahlung der Erde auf dem Weg ins All. «-!8!-
## <sub class="subscript">**8**</sub> [Sibylle Anderl: _Tausende Tonnen von Ruß_, in: _Frankfurter Allgemeine Zeitung_, 20. Juli 2021, hier zit. <u>nach</u>](https://zeitung.faz.net/faz/deutschland-und-die-welt/2021-07-20/tausende-tonnen-von-russ/638225.html)

* [Wolke](Clouds_de)
