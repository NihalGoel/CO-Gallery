---
title: 'Feuer'
---

Es gibt verschiedene Bilder davon. Das Server-Gebäude des französischen Datenspeicheranbieters OVH steht in Flammen. Man sieht das Gebäude in voller Ausdehnung brennen. Schwarze Rauchwolken steigen von unten durch das Feuer rot beleuchtet in den noch dunkleren Nachthimmel. Auf weiteren Bildern ist das Gebäude am nächsten Morgen zu sehen. Die Wände sind beschädigt oder ganz zerstört. Der Lack der meisten Paneele ist bis zur Unkenntlichkeit zerschmolzen. Einige Wandsegmente haben Lüftungsschlitze. An ihnen ist die Farbe erhalten geblieben. Sie zeigt sich trotz der ganzen Zerstörung orange, lila, grün und hellgrau. **OVH** war zu diesem Zeitpunkt das größte europäische Unternehmen zur Datenspeicherung. Viele Kunden, die keine eigenen Sicherheitskopien hatten, haben ihre Daten verloren. Die Sicherheitskopien, die OVH den Kunden als Service anbot, wurden teilweise auch zerstört. **Ich habe** von dem Feuer durch einen Tweet von K. erfahren, mit der ich Monate vorher gemeinsam an einem Text schrieb. Ein Kapitel des Buchs, an dem sie mit zwei weiteren Personen arbeitete, war bei OVH gespeichert. Ich habe sie nicht gefragt, ob sie ein Backup hat.

* [Wolke](Clouds_de)

* [Speichern](Saving_de)




