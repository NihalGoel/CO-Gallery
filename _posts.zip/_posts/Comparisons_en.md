---
title: 'Comparisons'
---

Only through photography did it become possible to compare clouds across linguistic, national, and continental borders. It allows us to make objective judgments about shape, size, and composition. However, there are some key properties that cannot be depicted in photographs: electrostatic charges, or the microscopic particles on which water vapor condenses. Temperature and humidity cannot be photographed, either.

* [Photography](Photography_en)

* [Calculating](Calculating_en)
