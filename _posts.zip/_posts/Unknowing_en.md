---
title: 'Unknowing'
---

“And ween not, for I call it a darkness or a cloud, that it be any cloud congealed of the humours that flee in the air, nor yet any darkness such as is in thine house on nights when the candle is out. For such a darkness and such a cloud mayest thou imagine with curiosity of wit, for to bear before thine eyes in the lightest day of summer: and also contrariwise in the darkest night of winter, thou mayest imagine a clear shining light. Let be such falsehood. I mean not thus. For when I say darkness, I mean a lacking of knowing: as all that thing that thou knowest not, or else that thou hast forgotten, it is dark to thee; for thou seest it not with thy ghostly eye. And for this reason it is not called a cloud of the air, but a cloud of unknowing, that is betwixt thee and thy God.” -!27!-
## <sub class="subscript">**27**</sub> The Cloud of Unknowing, England, ca. 1390, here in Evelyn Underhill, ed., _A Book of Contemplation the Which Is Called the Cloud of Unknowing, in the Which a Soul Is Oned with God_ (London: John M. Watkins, 1922), 26. [Retrieved from <u>here</u>](www.catholicspiritualdirection.org/cloudunknowing.pdf) (accessed on September 8, 2021).

* [Beginnings](Beginnings_en)

* [Clouds](Clouds_en)
