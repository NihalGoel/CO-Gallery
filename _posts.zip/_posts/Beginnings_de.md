---
title: 'Anfang'
---

»Gott sprach: Dies ist das Zeichen des Bunds, den ich gebe zwischen mich und euch und alljede lebende Seele, die mit euch ist, auf Weltzeit-Geschlechter: meinen Bogen gebe ich ins Gewölk, er werde Zeichen des Bunds zwischen mir und der Erde.« -!1!-
## <sub class="subscript">**1**</sub> Buch Moses, Kapitel 9, Vers 12–13, zit. nach: _Die Schrift, zu verdeutschen unternommen von Martin Buber gemeinsam mit Franz Rosenzweig_, Bd. 1: Das Buch im Anfang, Berlin: Schneider, [1926].
**»Vor ihnen** einher ging ER, des Tags in einer Säule Gewölks, sie den Weg zu leiten, des Nachts in einer Säule Feuers, ihnen zu leuchten, zu gehen tags und nachts. Nicht wich die Wolkensäule des Tags und die Feuersäule des Nachts vor dem Volk.« -!2!-
## <sub class="subscript">**2**</sub> Buch Moses, Kapitel 13, Vers 21–22, zit. nach: _Die Schrift, zu verdeutschen unternommen von Martin Buber gemeinsam mit Franz Rosenzweig_, Bd. 2: Das Buch Namen, Berlin: Schneider, [1926].
»In der **Morgenwache geschahs**: ER bog sich gegen die Reihen Ägyptens nieder in der Säule Feuers und Gewölks und verstörte die Reihen Ägyptens, er lockerte das Rad seiner Gefährte und ließ es voranstreben mit Beschwer. Ägypten sprach: Fliehen will ich vor Jissrael, denn ER kämpft für sie gegen Ägypten.« -!3!-
## <sub class="subscript">**3**</sub> Buch Moses, Kapitel 14, Vers 24–25, zit. nach: _Die Schrift, zu verdeutschen unternommen von Martin Buber gemeinsam mit Franz Rosenzweig_, Bd. 2: Das Buch Namen, Berlin: Schneider, [1926].
**»Mosche stieg** empor den Berg, die Wolke hüllte den Berg, SEINE Erscheinung wohnte auf dem Berg Ssinai ein. Die Wolke hüllte ihn ein Tagsechst. Am siebenten Tag rief er Mosche mitten aus der Wolke. Das Ansehn SEINER Erscheinung war wie eines fressenden Feuers am Haupte des Bergs den Augen der Söhne Jissraels. Mosche kam mitten in die Wolke, er stieg auf zum Berg. Mosche blieb auf dem Berg vierzig Tage und vierzig Nächte. Das Zelt der Begegnung: das Urbild.« -!4!-
## <sub class="subscript">**4**</sub> Buch Moses, Kapitel 24, Vers 15–18, zit. nach: _Die Schrift, zu verdeutschen unternommen von Martin Buber gemeinsam mit Franz Rosenzweig_, Bd. 2: Das Buch Namen, Berlin: Schneider, [1926].

* [Wolke](Clouds_de)

* [Feuer](Fire_de)

* [Nichtwissen](Unknowing_de)







