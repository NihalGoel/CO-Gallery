---
title: 'Knowledge'
---

Philo and Gunge: You are in the presence of the all-knowing trash heap. Yeah. The trash heap knows all. The trash heap says all. **Marjory**: Let’s face it, boys. The trash heap is all. **Philo and Gunge**: Too true! **Marjory**: I am orange peels! I am coffee grounds! I am wisdom. **Gobo**: Greetings, Madame Heap. **Marjory**: And I know what this Fraggle has. **Philo and Gunge**: Well, of course you do! You’re all-knowing. **Marjory**: I know that! This young Fraggle has trouble. **Philo and Gunge**: Troubles? Gobo: I am bringing you my troubles. I’m sorry. **Marjory**: Sorry, what’s to be sorry? Trouble’s my favorite thing. -!17!-
##<sub class="subscript">**17**</sub> Fraggle Rock, “Beginnings,” retrieved from <u>[here</u>](https://www.youtube.com/watch?v=yZk1sfEK1NE), 24:50, December 26, 2019, (accessed on September 8, 2021).

* [The Cloud](Clouds_en)

* [Garbage](Dirt_en)

* [Saving](Saving_en)
