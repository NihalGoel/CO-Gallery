---
title: 'Hören'
---

»Wer den Verlauf in Zukunft schneller löschen will, kann das auch per Sprachbefehl. Direkt über der Zeitraumauswahl im selben Menü kann man auch diese Option aktivieren. Der Sprachbefehl ›Alexa, lösche alles, was ich heute gesagt habe‹ lässt alle Anfragen des bisherigen Tagesverlaufs verschwinden, auch nur der letzte Befehl lässt sich löschen. Längere Zeiträume sind allerdings nicht per Sprache loszuwerden, dafür muss man wieder die App öffnen.« -!14!-
## <sub class="subscript">**14**</sub> [Malte Mansholt, in: _Der Stern_, 12. März 2020, hier zit. <u>nach</u>](https://www.stern.de/digital/online/amazon-echo--so-loeschen-sie-auf-einen-schlag-alles--was-sie-je-zu-alexa-gesagt-haben-8743604.html).
**»Andere Mitarbeiter** notierten wiederum alles, was der Lautsprecher darüber hinaus aufnimmt – auch Gespräche im Hintergrund. Mitunter seien das auch vertrauliche Dinge, etwa Namen, Bankverbindungen oder Äußerungen von Kindern. In solchen Fällen sollen die Mitarbeiter einen Haken bei einer Checkbox für ›kritische Daten‹ setzen und mit der nächsten Audiodatei weitermachen.« -!15!-
## <sub class="subscript">**15**</sub> [Axel Kannenberg: _Amazon-Mitarbeiter tippen zum Teil Alexa-Sprach- befehle ab_, in: _heise.de_, 11. April 2019, zit. <u>nach</u>](https://heise.de/-4374871).

* [Wolke](Clouds_de)

* [Löschen](Clear%20Skies_de)

* [Speichern](Saving_de)
