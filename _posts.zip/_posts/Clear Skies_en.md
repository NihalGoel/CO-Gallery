---
title: 'Clear Skies'
---

“The first bomb could have hit Nagasaki. The visibility there was excellent, but the primary target, Hiroshima, and the city of Kokura, a third possible location, were obscured by heavy clouds. But suddenly the clouds over Hiroshima parted and the Enola Gay honed in on its target. Nagasaki was temporarily spared thanks to a stroke of meteorological luck, but only briefly: then the bomb fell there, too, sixty years ago today.” -!6!-
## <sub class="subscript">**6**</sub> Andreas Conrad, “Der Angriffs-Befehl kam aus Babelsberg,”[_Der Tagesspiegel (Berlin)_, August 9, 2000,](https://www.tagesspiegel.de/berlin/der-angriffs-befehl-kam-aus-babelsberg/631760.html) (accessed on September 8, 2021). Translated here by Sylee Gore.

* [Weather](Weather_en)

* [War](War_en)




