---
title: 'Füße'
---

»Der erste Mann des Staates sprach, das Mikro in der Hand. Er sei auf alle Fragen aus dem Volke nun gespannt. Gleich flogen ein paar Arme hoch. Die sprachen, standen auf. Was auch die Leute fragten – vorn gab ́s eine Antwort drauf. **Dann sprach** eine Ministerin und mal ein Kommandant. Die Antwort gab stets einer, der das Sachgebiet verstand. Nur ich verstand nicht allzuviel, mir reichte, was ich sah. Ich träumte nicht, ich saß dabei – in Nicaragua! Und die Versammlung hieß: **Mit dem** Gesicht zum Volke, mit dem Gesicht zum Volke, mit dem Gesicht zum Volke – nicht mit den Füßen in ́ner Wolke, nein! Mit dem Gesicht zum Volke, mit dem Gesicht zum Volke, mit dem Gesicht zum Volke – ja! **Hier las** kein Mensch vom Zettel ab, hier sprach man alles aus. Oft gab es Zwischenrufe und Gelächter und Applaus. Das findet immer wieder statt, und jeder darf da rein. Und keine Frage ist zu heiß und kein Problem zu klein.«-!12!-
## <sub class="subscript">**12**</sub> [Gerhard Schöne: _Mit dem Gesicht zum Volke_ [1988], hier zit. <u>nach</u>](https://verlag.buschfunk.com/alben/du-hast-es-nur-noch-nicht-probiert-live-dcd/#track1149).

