---
title: 'Rauch'
---

›Natürlich wisse er, dass der Rauch gefährlich ist‹ sagt Robert Ankrah, ein 21-Jähriger, der seit drei Jahren auf dem Elektroschrottplatz arbeitet. ›Aber was sollen wir machen? Wir haben keine Jobs. Sollen wir stehlen gehen?‹ Er und seine Kumpels wollten eben an das Kupfer in den Kabeln gelangen, das bringe am meisten Geld bei den Metallhändlern, umgerechnet zwischen ein und zwei Euro am Tag. **Deshalb brennt** der Mann mit der Wollmütze und dem Ziegenbart vom Morgengrauen bis zur Abenddämmerung die Gummi- und Plastikmäntel der Computerkabel weg. ›Ich habe keine Beschwerden‹, sagt er, ›ich bin stark, und Gott wird schon auf mich aufpassen.‹ Dann schmeißt er das nächste Kabelknäuel ins Feuer.« -!22!-
## <sub class="subscript">**22**</sub> [Michael Bitala: _Im Höllenfeuer der Hightech-Welt_, in: _Süddeutsche Zeitung_, 17. Mai 2010, hier zit. <u>nach</u>](https://www.sueddeutsche.de/wissen/ghana-im-hoellenfeuer-der-hightech-welt-1.689901?print=true).

* [Cloud](Clouds_de)

* [Fabrik](The%20Factory_de)

* [Sehnsucht](Longing_de)
