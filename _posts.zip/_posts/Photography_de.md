---
title: 'Fotografie'
---

»Natürlich sind Fotografien Kunstprodukte. Aber in einer von fotografischen Relikten übersäten Welt haben sie offenbar auch als Fundobjekte ihren Reiz, als zufällige Ausschnitte der Welt. Sie profitieren also gleichzeitig vom Prestige der Kunst und von der Magie der Wirklichkeit. Sie sind wolkige Gebilde der Phantasie und winzige Informationssplitter. Die Fotografie ist zur kennzeichnendsten Kunstform der rastlosen Überfluß- und Wegwerfgesellschaft geworden – zum unentbehrlichen Werkzeug der neuen Massenkultur, die sich in den USA nach dem Bürgerkrieg zu entwickeln begann, Europa aber erst nach dem Zweiten Weltkrieg eroberte, wenngleich ihre Tendenzen bereits Mitte des neunzehnten Jahrhunderts in wohlhabenden Kreisen Fuß gefaßt hatten, nämlich als – um eine sarkastische Bemerkung Baudelaires zu zitieren – ›unsere verlotterte Gesellschaft‹ in narzißtische Verzückung geriet über Daguerres ›billige Methode, Abscheu vor der Geschichte zu verbreiten‹.«-!10!-
## <sub class="subscript">**10**</sub> Susan Sontag: _Objekte der Melancholie_, in: dies.: _Über Fotografie_, Frankfurt am Main: Fischer, 2003 dt. Erstausgabe München/Wien: Hanser, 1978, S. 71.

* [Wissen](Knowledge_de)

* [Löschen](Deleting_de)

* [Speichern](Saving_de)
