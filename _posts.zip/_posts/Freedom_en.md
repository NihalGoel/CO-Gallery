---
title: 'Freedom'
---
“Freedom is said to be boundless there above the clouds, it is said that all fears, all anxieties are left behind down there, and then what appears to be grand and weighty would suddenly appear insignificant and small.” -!16!-
## <sub class="subscript">**16**</sub> Reinhard Mey, _Über den Wolken_ (1974), retrieved from <u>[here</u>](https://lyricstranslate.com/en/%C3%BCber-den-wolken-above-clouds.html-0#songtranslation) (accessed on September 8, 2021).

* [Feet](Feet_en)

* [Longing](Longing_en)
