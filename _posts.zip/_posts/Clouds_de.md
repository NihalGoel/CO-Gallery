---
title: 'Wolke'
---

“Vor diesen Eingang stellte sich Orpheus und spielte und sang, eingehüllt in die finstere Wolke der Trauer. 


**Zeus** nahm für sich den Himmel und die Erde in Anspruch. Seinen Thron errichtete er auf dem Olymp. Dieser Berg ist meistens in Wolken gehüllt.

**Sie versprechen** ihm, daß er die Sprache der Tiere verstehen, daß er auf den Wolken liege könne. Aber all das lockt ihn nicht heraus.” -!27!-  
## <sub class="subscript">**27**</sub> Michael Köhlmeier: _Sagen des klassischen Altertums_, München: Piper, 1996, S. 17, 77, 98.

* [Anfang](Beginnings_de)

* [Wolken, graue](Clozuds,%20Gray_de)
