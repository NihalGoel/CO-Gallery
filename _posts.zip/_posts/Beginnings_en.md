---
title: 'Beginnings'
---

“And God said: ‘This is the token of the covenant which I make between Me and you and every living creature that is with you, for perpetual generations: I have set My bow in the cloud, and it shall be for a token of a covenant between Me and the earth.’” -!1!-
## <sub class="subscript">**1**</sub> Gen. 9:12–13, in _The Holy Scriptures According to the Masoretic Text: A New Translation_ (Philadelphia: The Jewish Publication Society of America, 1917), 11.
“And the LORD went before them by day in a pillar of cloud, to lead them the way; and by night in a pillar of fire, to give them light; that they might go by day and by night: the pillar of cloud by day, and the pillar of fire by night, departed not from before the people.” -!2!-
## <sub class="subscript">**2**</sub> Gen. 13:21–22, in _The Holy Scriptures According to the Masoretic Text: A New Translation_, 94–95.
“And it came to pass in the morning watch, that the LORD looked forth upon the host of the Egyptians through the pillar of fire and of cloud, and discomfited the host of the Egyptians. And He took off their chariot wheels, and made them to drive heavily; so that the Egyptians said: ‘Let us flee from the face of Israel; for the LORD fighteth for them against the Egyptians.’” -!3!-
## <sub class="subscript">**3**</sub> Gen. 14:24–25, in _The Holy Scriptures According to the Masoretic Text: A New Translation_, 96.
“And Moses went up into the mount, and the cloud covered the mount. And the glory of the LORD abode upon mount Sinai, and the cloud covered it six days; and the seventh day He called unto Moses out of the midst of the cloud. And the appearance of the glory of the LORD was like devouring fire on the top of the mount in the eyes of the children of Israel. And Moses entered into the midst of the cloud, and went up into the mount; and Moses was in the mount forty days and forty nights.” -!4!-
## <sub class="subscript">**4**</sub> Gen. 24:15–18, in _The Holy Scriptures According to the Masoretic Text: A New Translation_, 110.

* [Clouds](Clouds_en)

* [Fire](Fire_en)

* [Unknowing](Unknowing_en)







