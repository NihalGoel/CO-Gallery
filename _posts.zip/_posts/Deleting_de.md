---
title: 'Löschen'
---
“Befolgen Sie die nachstehende Anleitung, um eine Datei oder einen Ordner aus Ihrem Dropbox-Konto auf dropbox.com, aus der Dropbox-Desktop-App oder der mobilen Dropbox-App zu löschen. Sie können gelöschte Dateien oder Ordner innerhalb eines bestimmten Zeitfensters wiederherstellen. Wie lange das möglich ist, hängt von Ihrem Dropbox-Abo ab.” -!17!-
##  <sub class="subscript">**17**</sub>Zit. <u>nach</u>(https://help.dropbox.com/de-de/files-folders/restore-delete/delete-files)
**Wenn Sie** in Dropbox eine Datei löschen, ist diese in der Ordnerstruktur Ihres Kontos nicht mehr sichtbar. Die Datei wird jedoch erst nach Ablauf des Wiederherstellungszeitraums endgültig gelöscht.” -!18!-
## <sub class="subscript">**18**</sub> [https://help.dropbox.com/de-de/files-folders/restore-delete/delete-files](https://help.dropbox.com/de-de/files-folders/restore-delete/delete-files)

* [Vertrauen](Trust_de)

* [Speichern](Saving_de)
