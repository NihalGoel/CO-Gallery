---
title: 'The Cloud'
---

“I was just about to reset my old iPhone when suddenly it uploaded my content to iCloud without my permission. Including pictures I sent to my boyfriend. On the cloud that I share with my dad. DON’T UPLOAD THEM THERE!!!😭  ” -!7!-
## <sub class="subscript">**7**</sub> [Taschentroll, “Just wanted to put my old iPhone back. . . the thing suddenly uploads my content to the iCloud without being asked. I share that with my dad, ”Twitter, July 13, 2021, retrieved from <u>[here</u>](https://twitter.com/Taschentroll/status/1414866541619949569?s=20) (accessed on September 8, 2021). Translated here by Sylee Gore.

* [Deleting](Deleting_en)
