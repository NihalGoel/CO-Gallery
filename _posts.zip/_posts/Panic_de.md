---
title: 'Panik'
---

»Eine Wolke aus radioaktiven Partikeln verteilt sich nach der Explosion im sowjetischen Atomkraftwerk Tschernobyl über Europa. Seit der Nacht zum 26. April 1986 haben sich die Teilchen in der Luft verteilt und sind von unterschiedlichen Windströmungen bis nach Japan gebracht worden. Erst der Regen spült die radioaktiven Partikel aus der Atmosphäre auf die Erde. In Bayern, Baden-Württemberg und Teilen Brandenburgs gehen in den Tagen nach dem GAU heftige Regenschauer nieder. Auch heute, 30 Jahre nach dem GAU sind die Radionuklide Cäsium-137 und Strontium-90 erst zur Hälfte zerfallen. Andere haben weitaus längere Halbwertzeiten. Bis heute ist die Strahlung von Tschernobyl in Deutschland messbar.« -!20!-
## <sub class="subscript">**20**</sub> [Dagny Lüdemann, “Die Wolke,” _Die Zeit_, April 22, 2016, zit. <u>nach</u>](https://www.zeit.de/wissen/umwelt/2016-04/tschernobyl-gau-wolke-1986-deutschland)
