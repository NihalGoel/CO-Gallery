---
title: 'Feet'
---

“The first statesman spoke, microphone in hand, ready to hear the people’s questions. Within seconds, hands flew up. They rose to their feet to speak. For every question, there was an answer from the front. **Then a** minister spoke, then a commanding officer. The answer always came from an expert on the subject. I didn’t understand much, but what I saw was enough. It was no dream: I was sitting there in Nicaragua! And they called the meeting: **‘Facing the** people, facing the people.’ With my face to the people—not with my feet in a cloud, no! Facing the people, facing the people—yes! **No one** read from their notes. They spoke about everything. There were interjections and laughter and applause, again and again, and all were welcome. No question was too big, no problem too small.” -!15!-
## <sub class="subscript">**15**</sub> Gerhard Schöne, “Mit dem Gesicht zum Volke” (1988), retrieved from [here](https://verlag.buschfunk.com/alben/du-hast-es-nur-noch-nicht-probiert-live-dcd/#track1149) (accessed on September 8, 2021). Translated here by Sylee Gore.




