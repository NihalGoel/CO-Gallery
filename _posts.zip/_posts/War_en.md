---
title: 'War'
---

During the First World War, Arnold Schoenberg attempted to draw parallels between the events of the war and meteorological phenomena in his “cloud diary.” He believed that supernatural powers exerted a significant influence on both the war and the weather. After some time, when he failed to establish a clear connection, he stopped making diary entries. He resumed toward the end of the war as means of reacting to his horror. -!28!-

## <sub class="subscript">**28**</sub> Arnold Schoenberg, “War-Clouds Diary,” trans. Paul A. Pisk, _Journal of the Arnold Schoenberg Institute_ 9, no. 1 (June 1986): 53.
