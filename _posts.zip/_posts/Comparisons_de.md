---
title: 'Vergleich'
---

Erst die Nutzung der Fotografie ermöglichte es, die Wolken über Sprach-, Landes- und Kontinentalgrenzen zu vergleichen. Bezüglich Form, Größe und Anordnung konnte nun objektiv geurteilt werden. Einige ganz wesentliche Eigenschaften können auf Fotos jedoch nicht dargestellt werden: die elektrostatische Aufladung, die mikroskopisch kleinen Schwebteilchen, an denen der Wasserdampf kondensiert. Auch nicht die Temperatur und die Luftfeuchtigkeit.

* [Fotografie](Photography_de)

* [Rechnen](Calculating_de)
