---
title: 'Wetter'
---

Es regnet seit mehr als 24 Stunden. Wir befinden uns praktisch in der Wolke.
**Am blauen** Himmel ist keine Wolke zu sehen. Schon auf dem kurzen Weg vom Hotel zur vorläufigen Arbeitswohnung spüre ich, dass die Luft noch frisch ist. **Jetzt, wo** einige Zeit vergangen ist, sind wieder einzelne Wolken am Himmel. Sie sind in der Lage, die Sonne zeitweise zu verdecken. **Der Himmel** ist grau mit wenigen Abstufungen. Es fällt immer wieder Regen. **Der Regen** fällt gleichmäßig und stark. **Der Himmel** wird heller. Der Regen schwächt sich ab. Heute ist die Wolke etwa so groß wie die Burg, die auf dem Berg liegt. Oben ist sie heller als unten. Die Sonne schafft es nicht, durch die Wolken zu dringen. **Es ist **wieder viel grauer. Auch beginnt es zu regnen.** Es regnet**. Der graue Himmel ist von hellen Streifen durchzogen. Einzelne Wolken lassen sich abgrenzen. Ich kann immer noch nicht fassen, wie riesig die Wolken im Vergleich zur Burg aussehen. Ich weiß natürlich, dass die Burg sich in einer Entfernung von etwa 600 Metern befindet. Ich weiß auch, dass das eine optische Wirkung ist. Aber ich staune.
