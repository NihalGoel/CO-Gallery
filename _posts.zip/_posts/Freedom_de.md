---
title: 'Freiheit'
---

»Über den Wolken muss die Freiheit wohl grenzenlos sein. Alle Ängste, alle Sorgen, sagt man, Blieben darunter verborgen und dann Würde, was uns groß und wichtig erscheint, Plötzlich nichtig und klein« -!11!-
## <sub class="subscript">**11**</sub> [Reinhard Mey: Über den Wolken [1974], hier zit. <u>nach</u>](https://www.reinhard-mey.de/wp-content/uploads/2021/02/Reinhard-Mey-Textsammlung-14.Auflage.pdf)

* [Füße](Feet_de)

* [Sehnsucht](Longing_de)
