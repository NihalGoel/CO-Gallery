---
title: 'Wolken, graue'
---

“Eingehüllt in graue Wolken / Schlafen jetzt die großen Götter / Und ich höre, wie sie schnarchen / Und wir haben wildes Wetter. **Wildes Wetter!** Sturmeswüten Will / das arme Schiff zerschellen / Ach, wer zügelt diese Winde Und die herrenlosen Wellen! **Kanns nicht** hindern, daß es stürmet / Daß da dröhnen Mast und Bretter, Und ich hüll mich in den Mantel / Um zu schlafen wie die Götter.” -!28!-

## <sub class="subscript">**28**</sub> [Heinrich Heine: Eingehüllt in graue Wolken, aus ders.: _Heimkehr_ [1830], hier zit. <u>nach</u>](https://www.staff.uni-mainz.de/pommeren/Gedichte/HeineNachlese/wolken.html).
