---
title: 'Saving'
---
According to Jeff Bezos, saving is cheaper than deleting. I haven’t been able to find the source of that statement. From what I know about the logic behind economic growth, how cloud providers deal with user data, and how I handle my own archive, I have no doubt that he’s right.

* [About the Text](About%20This%20Text_en)

* [Deleting](Deleting_en)
