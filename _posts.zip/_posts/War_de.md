---
title: 'Krieg'
---

Arnold Schönberg versuchte während des Ersten Weltkriegs, Verbindungen zwischen Wetterphänomenen und dem Kriegsgeschehen herzustellen. Er führte ein Wolkentagebuch. Er glaubte, übernatürliche Mächte übten jeweils einen erkennbaren Einfluss aus. Als er nach einer Weile keinen verständlichen Zusammenhang feststellen konnte, stoppte er diese Aufzeichnungen. Gegen Ende des Krieges nahm er sie wieder auf, um irgendwie auf das Grauen zu reagieren. -!16!-

## <sub class="subscript">**16**</sub> Vgl. _Journal of the Arnold Schoenberg Institute_, 9, 1986, S. 53.
