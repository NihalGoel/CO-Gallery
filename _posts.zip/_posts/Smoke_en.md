---
title: 'Smoke'
---

“‘Of course I know that the smoke is dangerous,’ says twenty-one-year-old Robert Ankrah, who has been working at the e-waste dump for three years. ‘But what are we meant to do? We have no jobs. Do we go out and steal, then?’ He and his friends just wanted to extract the copper —the most valuable to metal traders— from the cables, which can amount to one to two euros a day. This is why Ankrah, with his woolen cap and goatee, burns the rubber and plastic casing of the computer cables all day long. ‘I have nothing to complain about. I’m strong, and God will take care of me,’ he says, throwing another bundle of cables into the fire.” -!24!-

## <sub class="subscript">**24**</sub> [Michael Bitala, “Im Höllenfeuer der Hightech-Welt,” _Süddeutsche Zeitung_, May 17, 2010,retrieved from <u>[here</u>](https://www.sueddeutsche.de/wissen/ghana-im-hoellenfeuer-der-hightech-welt-1.689901?print=true) (accessed on September 8, 2021). Translated here by Sylee Gore.

* [The Cloud](Clouds_en)

* [Factories](The%20Factory_en)

* [Longing](Longing_en)

