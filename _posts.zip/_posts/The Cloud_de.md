---
title: 'Cloud'
---

»Wollte gerade mein altes iPhone zurück setzen... da lädt das Ding auf einmal unaufgefordert meine Inhalte in die iCloud hoch. **Die ich** mit meinem Papa teile. Mit den Fotos, die ich an meinen Freund geschickt habe. **BITTE LASS** DIE FOTOS DA NICHT HOCHGELADEN SEIN!!!😭   «-!6!-
## <sub class="subscript">**6**</sub> [Tweet von Taschentroll, 13. Juli 2021, zit. <u>nach</u>](https://twitter.com/Taschentroll/status/1414866541619949569?s=20)

* [Löschen](Deleting_de)
