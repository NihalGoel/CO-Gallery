---
title: 'Longing'
---

The uniform grid of the platform is made of gray terrazzo tiles. We can see a purple suitcase and a pink one. A black duffel bag, too. Our gaze is directed downward. The light isn’t dim, but it has no clear source, either. The figure in the foreground wears dark blue jeans with white clouds on them.
**K. is** standing in the kitchen, on the warm parquet flooring. He is wearing boxers, light blue with white outlines of clouds. The upper half is white, the lower darker. The word “Simpsons” is printed all over the boxers.
**At the** entrance to the shopping arcade, by the supermarket, bakery, and snack bar, I have spent some time observing an elderly man in a state of total neglect. His clothes are dirty. He often lies right on the floor behind the glass door at the entrance. Sometimes he’ll sit on an old school chair. He often has a cup of coffee with him. Sometimes it’s a beer.
**The last** time I saw him, he came toward me on the street next to the arcade. His jacket and pants were in awful shape. Underneath, however, his T-shirt peeked through, light blue with clouds on it. It looked brand new.

