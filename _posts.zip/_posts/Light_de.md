---
title: 'Licht'
---

Ich bin 17 Jahre alt und seit einem Jahr im Fotozirkel, den M. leitet. Ich stehe mit ihm auf den Stufen des Schauspielhauses in Berlin. Er macht Fotos für eine Musikgruppe. Ich assistiere. Das Wetter ist wechselhaft. Immer wieder verdeckt eine Wolke zeitweise die Sonne. M. weist mich darauf hin, dass das einen Einfluss auf die Beleuchtung und die Belichtungszeit hat.

* [Fotografie](Photography_de)
